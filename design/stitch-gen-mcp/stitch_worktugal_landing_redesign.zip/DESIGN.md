---
name: Worktugal
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#414944'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#717974'
  outline-variant: '#c0c8c3'
  surface-tint: '#3b6756'
  primary: '#00261a'
  on-primary: '#ffffff'
  primary-container: '#0f3d2e'
  on-primary-container: '#7ba894'
  inverse-primary: '#a2d1bb'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#18231d'
  on-tertiary: '#ffffff'
  tertiary-container: '#2d3832'
  on-tertiary-container: '#95a19a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#beedd7'
  primary-fixed-dim: '#a2d1bb'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#234f3f'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#d9e6dd'
  tertiary-fixed-dim: '#bdcac1'
  on-tertiary-fixed: '#131e19'
  on-tertiary-fixed-variant: '#3e4943'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
  pill-text:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  section-gap: 80px
---

## Brand & Style
This design system is built to bridge the gap between technical AI innovation and the organic, human nature of career growth within Europe. The brand personality is professional and authoritative, yet avoids the coldness of traditional enterprise software by utilizing a "Warm SaaS" aesthetic. 

The visual direction centers on **Glassmorphism** and **Organic Minimalism**. By layering semi-transparent surfaces over subtle green gradient blurs, the UI achieves a sense of depth and modern sophistication. It communicates transparency and clarity, essential for a job board, while the deep emerald tones evoke stability and growth.

## Colors
The palette is anchored by **Deep Emerald (#0F3D2E)**, providing a high-contrast, professional foundation for text and primary branding. **Bright Emerald (#10B981)** serves as the high-energy accent for calls to action and success states, reflecting the "AI" spark.

The background is a soft, off-white off-slate to reduce eye strain and provide a canvas for the glass effects. Tertiary greens are used for subtle highlights and container fills, while neutrals manage the secondary information architecture.

## Typography
The typographic hierarchy uses **Plus Jakarta Sans** for headlines to provide a soft, contemporary, and welcoming geometric feel. Weights are kept heavy (Bold/ExtraBold) for headlines to ensure clear information hierarchy.

**Inter** is utilized for all body text, UI labels, and data points. Its neutral, utilitarian design ensures maximum legibility for job descriptions and search results. For specialized labels like pill badges, a higher font weight and slight tracking increase are applied to maintain clarity at small scales.

## Layout & Spacing
This design system employs a **Fixed Grid** model for desktop, centered within the viewport at 1280px. A 12-column system is used with generous 24px gutters to allow the glassmorphism cards enough "breathable" space to maintain their visual weight without feeling cluttered.

Spacing follows an 8px linear scale. Large-scale section gaps (80px+) are encouraged to separate the AI search experience from the job listings, reinforcing the modern, clean SaaS aesthetic. On mobile, margins shrink to 16px, and the 12-column grid collapses into a single-column stack.

## Elevation & Depth
Depth is the defining characteristic of this design system. It is achieved through two primary methods:

1.  **Glassmorphism Layers:** Background surfaces use a `backdrop-filter: blur(12px)` combined with a semi-transparent white fill (`rgba(255, 255, 255, 0.7)`). These surfaces must have a 1px inner border of pure white at 20% opacity to simulate light catching the edge of the glass.
2.  **Ambient Shadows:** Rather than harsh black shadows, we use "Deep Emerald Tints." Shadows should be highly diffused (30px-50px blur) with low opacity (approx 8%) and a slight green hue to blend naturally with the background blurs.
3.  **Gradient Blurs:** Large, soft blobs of color (#10B981 and #0F3D2E at 10% opacity) are placed behind the glass layers to create a sense of environmental light and "warmth."

## Shapes
The shape language is consistently **Rounded**. Standard components like input fields and smaller cards use a 0.5rem (8px) radius. Larger glass containers and featured job cards utilize 1rem (16px) for a more modern, friendly appearance. 

The "Pill" shape is reserved exclusively for status indicators, category badges, and tags, providing a distinct visual contrast to the more rectangular structure of the primary cards.

## Components
-   **Primary Action Buttons:** Solid Deep Emerald (#0F3D2E) background with white text. They must include a right-aligned icon (e.g., an arrow or Sparkle icon for AI features). Hover states transition to Bright Emerald (#10B981).
-   **Glass-morphism Cards:** The primary container for job listings. Features a subtle shadow, the 12px backdrop blur, and a 1px translucent border.
-   **Small Pill Badges:** Used for job tags (e.g., "Remote," "Full-time"). These should have a secondary emerald background (#F0FDF4) with deep emerald text to ensure high legibility.
-   **Input Fields:** Ghost-style inputs with a light gray border that transitions to a 2px Bright Emerald border on focus.
-   **AI Sparkle Indicators:** Use the Bright Emerald accent color for any AI-generated content or "Auto-match" features to signal innovation and precision.
-   **Search Bar:** A large, floating glass-morphism element with a centered layout, acting as the focal point of the landing page.